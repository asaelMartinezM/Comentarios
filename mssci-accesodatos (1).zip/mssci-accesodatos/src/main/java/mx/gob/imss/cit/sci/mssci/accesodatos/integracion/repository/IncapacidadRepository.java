package mx.gob.imss.cit.sci.mssci.accesodatos.integracion.repository;

import java.util.List;

import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadesDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.exceptions.BusinessException;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.ConsultaIncapacidadRequest;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.IncapacidadGraficaModel;

public interface IncapacidadRepository {
	
	List<ConsultaIncapacidadesDTO> consultaIncapacidadPorAdscripcion(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS, Integer limit, Integer offset) throws BusinessException;
	Integer consultaIncapacidadPorAdscripcionCount(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS) throws BusinessException;
	List<ConsultaIncapacidadesDTO> consultaIncapacidadPorExpedicion(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS, Integer limit, Integer offset) throws BusinessException;
	Integer consultaIncapacidadPorExpedicionCount(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS) throws BusinessException;
	
	ConsultaIncapacidadDTO consultaDetalleCaso(Long idCaso) throws BusinessException;
	String consultaUltimaCargaNSSA() throws BusinessException;
	void agregaComentarioDiagnostico(ConsultaIncapacidadDTO consultaDTO, Long idCaso) throws BusinessException;
	List<IncapacidadGraficaModel> consultaIncapacidadesPorCaso(Long idCaso) throws BusinessException;
}
