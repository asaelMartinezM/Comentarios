package mx.gob.imss.cit.sci.mssci.accesodatos.validation;

import javax.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ComentarioDTO;

@Service
@Validated
public class CustomValidation {
	
	@Validated(OnCreate.class)
	public void createComentarioValidation(@Valid ComentarioDTO comentarioDTO) {
	}
	
	@Validated(OnUpdate.class)
	public void updateComentarioValidation(@Valid ComentarioDTO comentarioDTO) {	
	}
	
	
}
