package mx.gob.imss.cit.sci.mssci.accesodatos.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadesDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.PaginadoConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.enums.EnumHttpStatus;
import mx.gob.imss.cit.sci.mssci.accesodatos.exceptions.BusinessException;
import mx.gob.imss.cit.sci.mssci.accesodatos.integracion.repository.IncapacidadRepository;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.ConsultaIncapacidadRequest;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.IncapacidadGraficaModel;
import mx.gob.imss.cit.sci.mssci.accesodatos.service.IncapacidadService;

@Service
public class IncapacidadServiceImpl implements IncapacidadService {

	private static final Logger LOG = LoggerFactory.getLogger(IncapacidadServiceImpl.class);
	
	@Autowired
	IncapacidadRepository incapacidadRepository;
	
	@Override
	public PaginadoConsultaIncapacidadDTO consultaIncapacidades(ConsultaIncapacidadRequest params, Integer limit, Integer offset) throws BusinessException {

		List<ConsultaIncapacidadesDTO> paginadoIncapacidad = null;
		PaginadoConsultaIncapacidadDTO paginadoResponse = null;
		Integer incapacidadesTotales = null;
		Integer isEmpIMSS = null;
		Integer isntEmpIMSS = null;

		validateConsultaIncParams(params, limit, offset);

		offset = offset > 0 ? offset-1 : 0;
		
		if (params.getIsEmpleadoIMSS() != null && params.getIsEmpleadoIMSS() == true) {
			isEmpIMSS = 4;
		} else if (params.getIsEmpleadoIMSS() != null && params.getIsEmpleadoIMSS() == false) {
			isntEmpIMSS = 4;
		}
		
		if (params.getIsAdscripcion()) {
			paginadoIncapacidad = incapacidadRepository.consultaIncapacidadPorAdscripcion(params, isEmpIMSS, isntEmpIMSS, limit, offset);
			if (paginadoIncapacidad!= null && !paginadoIncapacidad.isEmpty()) {
				if (offset <=1) {
					incapacidadesTotales = incapacidadRepository.consultaIncapacidadPorAdscripcionCount(params, isEmpIMSS, isntEmpIMSS);
				}
				paginadoResponse = new PaginadoConsultaIncapacidadDTO();
				paginadoResponse.setConsultaIncapacidadList(paginadoIncapacidad);
				paginadoResponse.setNumIncapacidades(incapacidadesTotales);
			}
		} else {
			paginadoIncapacidad = incapacidadRepository.consultaIncapacidadPorExpedicion(params, isEmpIMSS, isntEmpIMSS,limit, offset);
			if (paginadoIncapacidad!= null && !paginadoIncapacidad.isEmpty()) {
				if (offset <=1) {
					incapacidadesTotales = incapacidadRepository.consultaIncapacidadPorExpedicionCount(params, isEmpIMSS, isntEmpIMSS);
				}
				paginadoResponse = new PaginadoConsultaIncapacidadDTO();
				paginadoResponse.setConsultaIncapacidadList(paginadoIncapacidad);
				paginadoResponse.setNumIncapacidades(incapacidadesTotales);
			}
		}
		
		if (paginadoIncapacidad == null || paginadoIncapacidad.isEmpty()) {
			throw new BusinessException(EnumHttpStatus.CLIENT_ERROR_NOT_FOUND, "No se encontraron registros que cumplan con los criterios de busqueda", EnumHttpStatus.CLIENT_ERROR_NOT_FOUND.getDescription());
		}
		
		String ultimaCarga = incapacidadRepository.consultaUltimaCargaNSSA();
		paginadoResponse.setUltimaCargaNSSA(ultimaCarga);

		return paginadoResponse;
	}

	@Override
	public ConsultaIncapacidadDTO consultaIncapacidadPorIdCaso(Long idCaso) throws BusinessException {
		ConsultaIncapacidadDTO detalleCaso = null;

		if (idCaso==null) {
			LOG.debug("Error al validar campos requeridos");
			throw new BusinessException(EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST, "La propiedad idCaso es requerida", EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST.getDescription());
		}
		
		detalleCaso = incapacidadRepository.consultaDetalleCaso(idCaso);
		
		if ( detalleCaso == null ) {
			throw new BusinessException(EnumHttpStatus.CLIENT_ERROR_NOT_FOUND, "Registro no encontrado", EnumHttpStatus.CLIENT_ERROR_NOT_FOUND.getDescription());
		}

		String ultimaCarga = incapacidadRepository.consultaUltimaCargaNSSA();
		detalleCaso.setUltimaCargaNSSA(ultimaCarga);
		incapacidadRepository.agregaComentarioDiagnostico(detalleCaso, idCaso);

		List<IncapacidadGraficaModel> incapacidades = incapacidadRepository.consultaIncapacidadesPorCaso(idCaso);
		if (incapacidades.size() > 0) {
			detalleCaso.setLimiteDias(incapacidades.get(0).getDiasLimite());
			detalleCaso.setIncapacidadGraficaModel(incapacidades);			
		}

		return detalleCaso;
	}
	
	private void validateConsultaIncParams(ConsultaIncapacidadRequest params, Integer limit, Integer offset) throws BusinessException {

		if (params.getIdDelegacion()==null) {
			LOG.debug("Error al validar campos requeridos");
			throw new BusinessException(EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST, "La propiedad idDelegacion es requerida", EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST.getDescription());
		}
		
		if (limit == null) {			
			LOG.debug("Error al validar campos requeridos");
			throw new BusinessException(EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST, "La propiedad limit es requerida", EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST.getDescription());
		}

		if (offset == null) {
			LOG.debug("Error al validar campos requeridos");
			throw new BusinessException(EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST, "La propiedad offset es requerida", EnumHttpStatus.CLIENT_ERROR_BAD_REQUEST.getDescription());
		}
		
		if (params.getIsAdscripcion() == null) {
			params.setIsAdscripcion(false);
		}

		// Se valida que las propiedades no sean String vacios
		if (params.getAmaterno() != null && params.getAmaterno().trim().length() == 0)
		    params.setAmaterno(null);
		if (params.getApaterno() != null && params.getApaterno().trim().length() == 0)
		    params.setApaterno(null);
		if (params.getNombre() != null && params.getNombre().trim().length() == 0)
		    params.setNombre(null);
		if (params.getAmaterno() != null && params.getAmaterno().trim().length() == 0)
		    params.setAmaterno(null);
		if (params.getCurp() != null && params.getCurp().trim().length() == 0)
		    params.setCurp(null);
		if (params.getNss() != null && params.getNss().trim().length() == 0)
		    params.setNss(null);
		
	}
}
