package mx.gob.imss.cit.sci.mssci.accesodatos.model;

public class UsuarioSIAP {

}
