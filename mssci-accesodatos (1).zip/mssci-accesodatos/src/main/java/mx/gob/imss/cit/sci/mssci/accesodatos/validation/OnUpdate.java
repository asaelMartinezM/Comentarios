package mx.gob.imss.cit.sci.mssci.accesodatos.validation;

public interface OnUpdate {

}
