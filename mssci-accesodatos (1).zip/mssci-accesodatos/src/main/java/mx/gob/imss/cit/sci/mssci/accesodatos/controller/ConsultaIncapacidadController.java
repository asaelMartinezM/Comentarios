package mx.gob.imss.cit.sci.mssci.accesodatos.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.PaginadoConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.exceptions.BusinessException;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.ConsultaIncapacidadRequest;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.RespuestaError;
import mx.gob.imss.cit.sci.mssci.accesodatos.service.IncapacidadService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/mssci-accesodatos/v1")
public class ConsultaIncapacidadController {

	public static final Logger LOG = LoggerFactory.getLogger(ConsultaIncapacidadController.class);
	
	@Autowired
	private IncapacidadService incapacidadService;

	@PostMapping(value = "/consultaIncapacidad", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> obtenerIncapacidades(
		@RequestParam(value = "limit", required=true)Integer limit,
		@RequestParam(value = "offset", required=true)Integer offset,
		@RequestBody ConsultaIncapacidadRequest params
		) {
		ResponseEntity<?> responseEntity = null;

		try {

			PaginadoConsultaIncapacidadDTO paginadoIncapacidad = incapacidadService.consultaIncapacidades(params, limit, offset);
        	responseEntity = new ResponseEntity<>(paginadoIncapacidad, HttpStatus.OK);

		} catch (BusinessException be) {

			LOG.info("Error al consultar incapacidades: {}", be);

            int numberHTTPDesired = Integer.parseInt(be.getRespuestaError().getCode());

			RespuestaError respuestaError = be.getRespuestaError();
			responseEntity = new ResponseEntity<>(respuestaError, HttpStatus.valueOf(numberHTTPDesired));

		}

		return responseEntity;
	}

	@GetMapping(value = "/consultaIncapacidad/{idCaso}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> obtenerIncapacidadesDetalle(@PathVariable(value = "idCaso", required = true)Long idCaso) {
		ResponseEntity<?> responseEntity = null;

		try {

			ConsultaIncapacidadDTO paginadoIncapacidad = incapacidadService.consultaIncapacidadPorIdCaso(idCaso);
        	responseEntity = new ResponseEntity<>(paginadoIncapacidad, HttpStatus.OK);

		} catch (BusinessException be) {

			LOG.info("Error al consultar detalle de incapacidad con id: {}", idCaso);

            int numberHTTPDesired = Integer.parseInt(be.getRespuestaError().getCode());

			RespuestaError respuestaError = be.getRespuestaError();
			responseEntity = new ResponseEntity<>(respuestaError, HttpStatus.valueOf(numberHTTPDesired));

		}

		return responseEntity;
	}
}
