package mx.gob.imss.cit.sci.mssci.accesodatos.service;

import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.PaginadoConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.exceptions.BusinessException;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.ConsultaIncapacidadRequest;

public interface IncapacidadService {

	PaginadoConsultaIncapacidadDTO consultaIncapacidades(ConsultaIncapacidadRequest params, Integer limit, Integer offset) throws BusinessException;
	
	ConsultaIncapacidadDTO consultaIncapacidadPorIdCaso(Long idCaso) throws BusinessException;
}
