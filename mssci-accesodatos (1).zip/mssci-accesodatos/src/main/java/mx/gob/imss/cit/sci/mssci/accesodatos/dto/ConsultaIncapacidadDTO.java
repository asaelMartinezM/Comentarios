package mx.gob.imss.cit.sci.mssci.accesodatos.dto;

import java.util.List;

import mx.gob.imss.cit.sci.mssci.accesodatos.model.IncapacidadGraficaModel;

public class ConsultaIncapacidadDTO {

	private Long idPaciente;
	private String nombrePaciente;
	private String nss;
	private String curp;
	private String nombreUnidad;
	private String umf;
	private String nombreTurno;
	private String descRamo;
	private String descOcupacion;
	private Double montoAcumuladoSubsidio;
	private String ultimoDiagnostico;
	private String cveCie;
	private int dpr;
	private String matricula;
	private String cveRegistroPatronal;
	private String situacionActual;
	private String comentario;
	private String ultimaCargaNSSA;
	private String inicioCaso;
	private String finCaso;
	private int limiteDias;
	
	private List<IncapacidadGraficaModel> incapacidadGraficaModel;

	public ConsultaIncapacidadDTO() {}

	public String getNombrePaciente() {
		return nombrePaciente;
	}

	public void setNombrePaciente(String nombrePaciente) {
		this.nombrePaciente = nombrePaciente;
	}

	public Long getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(Long idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getNss() {
		return nss;
	}

	public void setNss(String nss) {
		this.nss = nss;
	}

	public String getCurp() {
		return curp;
	}

	public void setCurp(String curp) {
		this.curp = curp;
	}

	public String getNombreUnidad() {
		return nombreUnidad;
	}

	public void setNombreUnidad(String nombreUnidad) {
		this.nombreUnidad = nombreUnidad;
	}

	public String getUmf() {
		return umf;
	}

	public void setUmf(String umf) {
		this.umf = umf;
	}

	public String getNombreTurno() {
		return nombreTurno;
	}

	public void setNombreTurno(String nombreTurno) {
		this.nombreTurno = nombreTurno;
	}

	public String getDescRamo() {
		return descRamo;
	}

	public void setDescRamo(String descRamo) {
		this.descRamo = descRamo;
	}

	public String getDescOcupacion() {
		return descOcupacion;
	}

	public void setDescOcupacion(String descOcupacion) {
		this.descOcupacion = descOcupacion;
	}

	public Double getMontoAcumuladoSubsidio() {
		return montoAcumuladoSubsidio;
	}

	public void setMontoAcumuladoSubsidio(Double montoAcumuladoSubsidio) {
		this.montoAcumuladoSubsidio = montoAcumuladoSubsidio;
	}

	public String getUltimoDiagnostico() {
		return ultimoDiagnostico;
	}

	public void setUltimoDiagnostico(String ultimoDiagnostico) {
		this.ultimoDiagnostico = ultimoDiagnostico;
	}

	public String getCveCie() {
		return cveCie;
	}

	public void setCveCie(String cveCie) {
		this.cveCie = cveCie;
	}

	public int getDpr() {
		return dpr;
	}

	public void setDpr(int dpr) {
		this.dpr = dpr;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCveRegistroPatronal() {
		return cveRegistroPatronal;
	}

	public void setCveRegistroPatronal(String cveRegistroPatronal) {
		this.cveRegistroPatronal = cveRegistroPatronal;
	}

	public String getSituacionActual() {
		return situacionActual;
	}

	public void setSituacionActual(String situacionActual) {
		this.situacionActual = situacionActual;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public String getUltimaCargaNSSA() {
		return ultimaCargaNSSA;
	}

	public void setUltimaCargaNSSA(String ultimaCargaNSSA) {
		this.ultimaCargaNSSA = ultimaCargaNSSA;
	}

	public String getInicioCaso() {
		return inicioCaso;
	}

	public void setInicioCaso(String inicioCaso) {
		this.inicioCaso = inicioCaso;
	}

	public String getFinCaso() {
		return finCaso;
	}

	public void setFinCaso(String finCaso) {
		this.finCaso = finCaso;
	}

	public List<IncapacidadGraficaModel> getIncapacidadGraficaModel() {
		return incapacidadGraficaModel;
	}

	public void setIncapacidadGraficaModel(List<IncapacidadGraficaModel> incapacidadGraficaModel) {
		this.incapacidadGraficaModel = incapacidadGraficaModel;
	}

	public int getLimiteDias() {
		return limiteDias;
	}

	public void setLimiteDias(int limiteDias) {
		this.limiteDias = limiteDias;
	}

}
