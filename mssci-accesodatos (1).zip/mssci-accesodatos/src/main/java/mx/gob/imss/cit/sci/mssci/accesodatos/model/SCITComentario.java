package mx.gob.imss.cit.sci.mssci.accesodatos.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "scit_comentario")
@Getter
@Setter
public class SCITComentario implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@NotNull
	@Size(max = 10)
	@Column(name="cve_id_comentario")
	private Long idComentario;
	
	@Size(max = 10)
	@Column(name="cve_id_comentario_padre")
	private Long idComentarioPadre;
	
	@Size(max = 500)
	@Column(name="ref_texto")
	private String comentarioHechoAlCaso;

	@NotNull
	@Column(name="stp_fecha_comentario")
	private Date fecGeneracionComentario;
	
	@NotNull
	@Column(name="stp_fecha_revaloracion")
	private Date fecRevalorarCaso;
	
	@Size(max = 11)
	@Column(name="cve_matricula_alta")
	private String matriculaAlta;
	
	@Column(name="stp_actualiza_registro")
	private Date fecActualizaRegistro;
	
	@Size(max = 11)
	@Column(name="cve_matricula_actualiza")
	private String matriculaActualizaRegistro;
	
	@Column(name = "cve_id_caso")
    private Long idCaso;

	@ManyToOne
	@JoinColumn(name = "cve_id_usuario", nullable = false)
    private SCITUsuario usuarioEmiteComentario;
	
	@ManyToOne
	@JoinColumn(name = "cve_id_clasificacion", nullable = false)
	private SCICClasificacion clasificacion;
	
																						 

}
