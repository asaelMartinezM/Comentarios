package mx.gob.imss.cit.sci.mssci.accesodatos.integracion.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import mx.gob.imss.cit.sci.mssci.accesodatos.constants.SQLIncapacidadConstants;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.dto.ConsultaIncapacidadesDTO;
import mx.gob.imss.cit.sci.mssci.accesodatos.enums.EnumHttpStatus;
import mx.gob.imss.cit.sci.mssci.accesodatos.exceptions.BusinessException;
import mx.gob.imss.cit.sci.mssci.accesodatos.integracion.repository.IncapacidadRepository;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.ConsultaIncapacidadRequest;
import mx.gob.imss.cit.sci.mssci.accesodatos.model.IncapacidadGraficaModel;

@Repository("incapacidadRepository")
public class IncapacidadRepositoryImpl implements IncapacidadRepository {

	private static final Logger logger = LoggerFactory.getLogger(IncapacidadRepositoryImpl.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<ConsultaIncapacidadesDTO> consultaIncapacidadPorAdscripcion(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS, Integer limit, Integer offset) throws BusinessException {

		List<ConsultaIncapacidadesDTO> consultaIncapacidad = null;
		
		try {
			consultaIncapacidad = jdbcTemplate.query(SQLIncapacidadConstants.QS_CONSULTA_INCAPACIDADES_ADSCRIPCION,
									new Object[] {
											params.getEstadoIncapacidad(),
											params.getIdDelegacion(),
											params.getIdDelegacion(),
											params.getIdUnidad(),
											params.getIdUnidad(),
											params.getIdRamo(),
											params.getIdRamo(),
											isEmpIMSS,
											isEmpIMSS,
											isntEmpIMSS,
											isntEmpIMSS,
											params.getNss(),
											params.getNss(),
											params.getCurp(),
											params.getCurp(),
											params.getNombre(),
											params.getNombre(),
											params.getApaterno(),
											params.getApaterno(),
											params.getAmaterno(),
											params.getAmaterno(),
											offset,
											limit
											},
									(rs, rowNum) -> {
										ConsultaIncapacidadesDTO incapacidad = new ConsultaIncapacidadesDTO();
										incapacidad.setIdUnidad(rs.getLong("idUnidad"));
										incapacidad.setNombrePaciente(rs.getString("paciente").trim());
										incapacidad.setPrimerApellido(rs.getString("pApellido"));
										incapacidad.setSegundoApellido(rs.getString("sApellido"));
										incapacidad.setIdPaciente(rs.getLong("idPaciente"));
										incapacidad.setIdCaso(rs.getLong("idCaso"));
										incapacidad.setNss(rs.getString("nss"));
										incapacidad.setNombreUnidad(rs.getString("unidad"));
										incapacidad.setDiasAcumuladosIncapacidad(rs.getInt("diasAcumulados"));
										incapacidad.setInicioCaso(rs.getString("inicioCaso"));
										incapacidad.setFinCaso(rs.getString("finCaso"));
										return incapacidad;
									});

		} catch (Exception ex) {
			logger.debug("Error al consultar incapacidad por adscripcion");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al consultar incapacidad por adscripcion", ex.getMessage());
		}

		return consultaIncapacidad;
	}

	@Override
	public Integer consultaIncapacidadPorAdscripcionCount(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS) throws BusinessException {

		Integer totalRegistro = null;

		try {

			totalRegistro = jdbcTemplate.queryForObject(
								SQLIncapacidadConstants.QS_CONSULTA_INCAPACIDADES_ADSCRIPCION_COUNT,
								new Object[] {
										params.getEstadoIncapacidad(),
										params.getIdDelegacion(),
										params.getIdDelegacion(),
										params.getIdUnidad(),
										params.getIdUnidad(),
										params.getIdRamo(),
										params.getIdRamo(),
										isEmpIMSS,
										isEmpIMSS,
										isntEmpIMSS,
										isntEmpIMSS,
										params.getNss(),
										params.getNss(),
										params.getCurp(),
										params.getCurp(),
										params.getNombre(),
										params.getNombre(),
										params.getApaterno(),
										params.getApaterno(),
										params.getAmaterno(),
										params.getAmaterno(),
										},
								(rs, rowNum) -> {
									return Integer.valueOf(rs.getInt("total"));
								});

		} catch (Exception ex) {
			logger.debug("Error al contar incapacidades por adscripcion");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al contar incapacidades por adscripcion", ex.getMessage());
		}
		
		return totalRegistro;
	}

	@Override
	public List<ConsultaIncapacidadesDTO> consultaIncapacidadPorExpedicion(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS, Integer limit, Integer offset) throws BusinessException {

			List<ConsultaIncapacidadesDTO> consultaIncapacidad = null;
			
			try {
				consultaIncapacidad = jdbcTemplate.query(SQLIncapacidadConstants.QS_CONSULTA_INCAPACIDADES_EXPEDICION,
										new Object[] {
												params.getEstadoIncapacidad(),
												params.getIdDelegacion(),
												params.getIdDelegacion(),
												params.getIdUnidad(),
												params.getIdUnidad(),
												params.getIdRamo(),
												params.getIdRamo(),
												isEmpIMSS,
												isEmpIMSS,
												isntEmpIMSS,
												isntEmpIMSS,
												params.getNss(),
												params.getNss(),
												params.getCurp(),
												params.getCurp(),
												params.getNombre(),
												params.getNombre(),
												params.getApaterno(),
												params.getApaterno(),
												params.getAmaterno(),
												params.getAmaterno(),
												offset,
												limit
												},
										(rs, rowNum) -> {
											ConsultaIncapacidadesDTO incapacidad = new ConsultaIncapacidadesDTO();
											incapacidad.setIdUnidad(rs.getLong("idUnidad"));
											incapacidad.setNombrePaciente(rs.getString("paciente").trim());
											incapacidad.setPrimerApellido(rs.getString("pApellido"));
											incapacidad.setSegundoApellido(rs.getString("sApellido"));
											incapacidad.setIdPaciente(rs.getLong("idPaciente"));
											incapacidad.setIdCaso(rs.getLong("idCaso"));
											incapacidad.setNss(rs.getString("nss"));
											incapacidad.setNombreUnidad(rs.getString("unidad"));
											incapacidad.setDiasAcumuladosIncapacidad(rs.getInt("diasAcumulados"));
											incapacidad.setInicioCaso(rs.getString("inicioCaso"));
											incapacidad.setFinCaso(rs.getString("finCaso"));
											return incapacidad;
										});
			} catch (Exception ex) {
				logger.debug("Error al consultar incapacidad por Expedicion");
				throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al consultar incapacidad por Expedicion", ex.getMessage());
			}

			return consultaIncapacidad;
	}

	@Override
	public Integer consultaIncapacidadPorExpedicionCount(ConsultaIncapacidadRequest params, Integer isEmpIMSS, Integer isntEmpIMSS) throws BusinessException {

		Integer totalRegistro = null;

		try {
			totalRegistro = jdbcTemplate.queryForObject(
								SQLIncapacidadConstants.QS_CONSULTA_INCAPACIDADES_EXPEDICION_COUNT,
								new Object[] {
										params.getEstadoIncapacidad(),
										params.getIdDelegacion(),
										params.getIdDelegacion(),
										params.getIdUnidad(),
										params.getIdUnidad(),
										params.getIdRamo(),
										params.getIdRamo(),
										isEmpIMSS,
										isEmpIMSS,
										isntEmpIMSS,
										isntEmpIMSS,
										params.getNss(),
										params.getNss(),
										params.getCurp(),
										params.getCurp(),
										params.getNombre(),
										params.getNombre(),
										params.getApaterno(),
										params.getApaterno(),
										params.getAmaterno(),
										params.getAmaterno(),
										},
								(rs, rowNum) -> {
									return Integer.valueOf(rs.getInt("total"));
								});
			
		} catch (Exception ex) {
			logger.debug("Error al contar incapacidades por Expedicion");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al contar incapacidades por Expedicion", ex.getMessage());
		}

		return totalRegistro;
	}

	@Override
	public ConsultaIncapacidadDTO consultaDetalleCaso(Long idCaso) throws BusinessException {
		
		ConsultaIncapacidadDTO detalleCaso = null;
		
		try {

			detalleCaso = jdbcTemplate.queryForObject(
					SQLIncapacidadConstants.QS_CONSULTA_DETALLE_INCAPACIDAD,
					new Object[] {idCaso},
					(rs, rowNum) -> {
						ConsultaIncapacidadDTO detalle = new ConsultaIncapacidadDTO();
						String papellido = rs.getString("papellido")!=null?" "+rs.getString("papellido").trim():"";
						String sapellido = rs.getString("sapellido")!=null?" "+rs.getString("sapellido").trim():"";
						detalle.setNombrePaciente(rs.getString("paciente").trim() + papellido + sapellido);
						detalle.setIdPaciente(rs.getLong("idPaciente"));
						detalle.setNss(rs.getString("nss").trim());
						detalle.setCurp(rs.getString("curp").trim());
						detalle.setNombreUnidad(rs.getString("unidad"));
						detalle.setUmf(rs.getString("umf"));
						detalle.setNombreTurno(rs.getString("turno"));
						detalle.setDescRamo(rs.getString("ramo"));
						detalle.setDescOcupacion(rs.getString("ocupacion"));
						detalle.setMontoAcumuladoSubsidio(rs.getDouble("montoAcumulado"));
						detalle.setUltimoDiagnostico(rs.getString("diagnostico"));
						detalle.setCveCie(rs.getString("cie"));
						detalle.setDpr(rs.getInt("dpr"));
						detalle.setMatricula(rs.getString("matMedico"));
						detalle.setCveRegistroPatronal(rs.getString("regPatronal"));
						detalle.setInicioCaso(rs.getString("inicioCaso"));
						detalle.setFinCaso(rs.getString("finCaso"));
						return detalle;
					});

		} catch (Exception ex) {
			logger.debug("Error al consultar el detalle de incapacidad");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al consultar el detalle de incapacidad", ex.getMessage());
		}

		return detalleCaso;
	}
	
	@Override
	public String consultaUltimaCargaNSSA() throws BusinessException {
		String ultimaCarga = null;
		try {
			ultimaCarga = jdbcTemplate.queryForObject(SQLIncapacidadConstants.QS_CONSULTA_PARAMETRO_ULTIMA_CARGA,
							(rs, rowNum) -> {
								return rs.getString("ultimaCarga");
							});
		} catch(Exception ex ) {
			logger.debug("Error al consultar ultima carga NSSA");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al consultar ultima carga NSSA", ex.getMessage());
		}
		
		return ultimaCarga;
	}
	
	public void agregaComentarioDiagnostico(ConsultaIncapacidadDTO consultaDTO, Long idCaso) throws BusinessException {

		try {
			ConsultaIncapacidadDTO result = jdbcTemplate.queryForObject(SQLIncapacidadConstants.QS_CONSULTA_ULTIMA_COMENTARIO,
							new Object[] {idCaso},
							(rs, rowNum) -> {
								ConsultaIncapacidadDTO detalle = null;
								if (rs!=null) {									
									detalle = new ConsultaIncapacidadDTO();
									detalle.setComentario(rs.getString("comentario"));
									detalle.setSituacionActual(rs.getString("situacionActual"));
								}
								return detalle;
							});

			if (result!=null) {
				consultaDTO.setComentario(result.getComentario());
				consultaDTO.setSituacionActual(result.getSituacionActual());
			}

		} catch (EmptyResultDataAccessException er){
			logger.debug("No se encontro ningun comentario para el caso: " + idCaso);
		} catch (Exception e) {
			logger.debug("Error al consultar ultimo comentario");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al consultar ultimo comentario", e.getMessage());
		}
	}
	
	public List<IncapacidadGraficaModel> consultaIncapacidadesPorCaso(Long idCaso) throws BusinessException {
		List<IncapacidadGraficaModel> incapacidadList = null;

		try {
			incapacidadList = jdbcTemplate.query(SQLIncapacidadConstants.QS_CONSULTA_LISTA_INCAPACIDAD,
							new Object[] {idCaso},
							(rs, rowNum) -> {
								IncapacidadGraficaModel incapacidades = new IncapacidadGraficaModel();
								incapacidades.setExpedicion(rs.getString("unidad"));
								incapacidades.setFolio(rs.getString("folio"));
								incapacidades.setDiasAutorizados(rs.getInt("dias"));
								incapacidades.setMatriculaMedico(rs.getString("medico"));
								incapacidades.setDiasLimite(rs.getInt("limite"));
								incapacidades.setNivelIncapacidad(rs.getInt("nivel"));
								incapacidades.setFechaInicio(rs.getString("fechaInicio"));
								incapacidades.setFechaFin(rs.getString("fechaFin"));
								return incapacidades;
							});
		} catch (Exception e) {
			logger.debug("Error al consultar listado de incapacidades");
			throw new BusinessException(EnumHttpStatus.SERVER_ERROR_INTERNAL, "Error al consultar listado de incapacidades", e.getMessage());
		}
		
		return incapacidadList;
	}
}
